/**
 @author Jie Chen
 */
/**
  interface ReceiptFormatter is Strategy, format method is required
 */
public interface ReceiptFormatter
{
   public String format();
}
